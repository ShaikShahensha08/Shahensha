﻿using Microsoft.EntityFrameworkCore;
using SearchManagement.API.Data;
using SearchManagement.API.DataModels;
using SearchManagement.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository
{
    public class MenuRepository : Repository<TblMenu>, IMenuRepository
    {
        public MenuRepository(RestaurantManagementContext context) : base(context) { }

        public async Task<IQueryable<MenuDetails>> GetRestaurantMenu(int restaurantID)
        {
            List<MenuDetails> menudetails = new List<MenuDetails>();
            try
            {
                
                if (_context != null)
                {
                    
                    var menudetail = await (from offer in _context.TblOffer
                                      join menu in _context.TblMenu on offer.TblMenuId equals menu.Id into TableMenu
                                      from menu in TableMenu
                                      join cuisine in _context.TblCuisine on menu.TblCuisineId equals cuisine.Id
                                      where offer.TblRestaurantId == restaurantID
                                      select new MenuDetails
                                      {
                                          tbl_Offer = offer,
                                          tbl_Cuisine = cuisine,
                                          tbl_Menu = menu
                                      }).ToListAsync();


                    foreach (var item in menudetail)
                    {
                        MenuDetails menuitem = new MenuDetails
                        {
                            tbl_Cuisine = item.tbl_Cuisine,
                            tbl_Menu = item.tbl_Menu,
                            tbl_Offer = item.tbl_Offer
                        };
                        menudetails.Add(menuitem);
                    }
                }
                return menudetails.AsQueryable();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
