﻿using SearchManagement.API.DataModels;
using SearchManagement.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository
{
    public interface IRestaurantRepository : IRepository<TblRestaurant>
    {
        TblRestaurant GetResturantDetails(int restaurantID);
        IQueryable<RestaurantSearchDetails> GetRestaurantsBasedOnLocation(LocationDetails location_Details);
        IQueryable<RestaurantSearchDetails> GetRestaurantsBasedOnMenu(AdditionalFeatureForSearch searchDetails);
        TblMenu ItemInStock(int restaurantID, int menuID);
    }
}
