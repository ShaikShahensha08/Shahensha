﻿using Microsoft.EntityFrameworkCore;
using SearchManagement.API.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        protected readonly RestaurantManagementContext _context;
        private readonly DbSet<T> _entities;

        public Repository(RestaurantManagementContext context)
        {
            _context = context;
            _entities = _context.Set<T>();
        }

        public async void Add(T entity)
        {
            await _entities.AddAsync(entity);
        }

        public async void AddRange(IEnumerable<T> entities)
        {
            await _entities.AddRangeAsync(entities);
        }

        public IEnumerable<T> Find(Expression<Func<T, bool>> expression)
        {
            return _entities.Where(expression);
        }

        public async Task<IEnumerable<T>> GetAll()
        {
            return  await _entities.ToListAsync();
        }

        public async Task<T> GetById(string id)
        {
            return await _entities.FindAsync(id);
        }

        public void Remove(T entity)
        {
            _entities.Remove(entity);
        }

        public void RemoveRange(IEnumerable<T> entities)
        {
            _entities.RemoveRange(entities);
        }

        public void Update(T entity)
        {
            _entities.Update(entity);
        }

        public async void SaveChanges()
        {
           await _context.SaveChangesAsync();
        }
    }
}
