﻿using SearchManagement.API.Data;
using SearchManagement.API.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository
{
    public class OfferRepository : Repository<TblOffer>, IOfferRepository
    {
        public OfferRepository(RestaurantManagementContext context) : base(context) { }
    }
}
