﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.DataModels
{
    public class TblStock
    {
        public int RestaurantID { get; set; }
        public int Quantity { get; set; }
    }
}
