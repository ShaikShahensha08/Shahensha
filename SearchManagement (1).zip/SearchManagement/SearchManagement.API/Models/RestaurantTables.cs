﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Models
{
    public class RestaurantTables
    {
        public string restaurant_Name { get; set; }
        public int table_Capacity { get; set; }
        public int total_Count { get; set; }
    }
}
