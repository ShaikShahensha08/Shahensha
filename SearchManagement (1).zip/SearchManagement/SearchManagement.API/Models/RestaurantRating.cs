﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Models
{
    public class RestaurantRating
    {
        public int RestaurantId { get; set; }
        public string rating { get; set; }
        public string user_Comments { get; set; }
        public int customerId { get; set; }
    }
}
