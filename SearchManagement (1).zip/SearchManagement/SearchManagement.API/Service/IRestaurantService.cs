﻿using SearchManagement.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Service
{
    public interface IRestaurantService
    {
        Task<IQueryable<RestaurantMenu>> GetRestaurantMenus(int restaurantID);
        IQueryable<RestaurantRating> GetRestaurantRating(int restaurantID);
        RestaurantInformation GetResturantDetails(int restaurantID);
        IQueryable<RestaurantTables> GetTableDetails(int restaurantID);
        IQueryable<RestaurantInformation> SearchRestaurantByLocation(LocationDetails locationDetails);
        IQueryable<RestaurantInformation> GetRestaurantsBasedOnMenu(AdditionalFeatureForSearch additionalFeatureForSearch);
        int ItemInStock(int restaurantID, int menuID);
        void RestaurantRating(RestaurantRating restaurantRating);
        IQueryable<RestaurantInformation> SearchForRestaurant(SearchForRestaurant searchDetails);
    }
}
